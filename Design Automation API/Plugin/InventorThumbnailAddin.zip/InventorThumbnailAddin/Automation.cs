﻿
// Automation.cs
using System;
using System.Text;
using System.Runtime.InteropServices;
using Inventor;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Security.Cryptography;
using System.Reflection;
using InventorThumbnailAddin;
using System.Threading;
using System.Globalization;
using System.IO.Compression;
using System.Linq;



namespace InventorThumbnailAddin
{
    [ComVisible(true)]

    
    public class Automation
    {
        private readonly Inventor.InventorServer _inventorApp;

        public Automation() { }

        public Automation(Inventor.InventorServer inventorApp)
        {
            _inventorApp = inventorApp;
        }

     

        public string ExtractJointsAndConstraintsInternal(string iamFilePath)
        {
            if (_inventorApp == null)
                throw new InvalidOperationException("Inventor application not initialized");

            AssemblyDocument assyDoc = null;

            try
            {
                Console.WriteLine($"[DEBUG] Attempting to open: {iamFilePath}");

                //assyDoc = _inventorApp.Documents.Open(iamFilePath, true) as AssemblyDocument;
                try { assyDoc = _inventorApp.Documents.Open(iamFilePath, true) as AssemblyDocument; }
                catch (Exception ex) { Console.WriteLine($"ex.Message: ${ex}"); }

                Console.WriteLine($"[ERROR]: {assyDoc}");

                if (assyDoc == null)
                    throw new InvalidOperationException("The specified file could not be opened as an AssemblyDocument");

                return GenerateJson(assyDoc);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[ERROR] Opening or processing assembly failed: {ex.Message}");
                throw;
            }
            finally
            {
                assyDoc?.Close();
            }
        }


        private string GenerateJson(AssemblyDocument assyDoc)
        {
            var sb = new StringBuilder();
            sb.AppendLine("{");

            // Basic properties
            sb.AppendLine($"  \"DisplayName\": \"{EscapeJsonString(assyDoc.DisplayName)}\",");
            sb.AppendLine($"  \"FullFileName\": \"{EscapeJsonString(assyDoc.FullFileName)}\",");
            sb.AppendLine($"  \"DocumentType\": \"{assyDoc.DocumentType}\",");


            // Referenced Documents
            sb.AppendLine("  \"ReferencedDocuments\": [");
            try
            {
                foreach (Document doc in assyDoc.ReferencedDocuments)
                {
                    sb.AppendLine($"    \"{EscapeJsonString(doc.FullFileName)}\",");
                }
            }
            catch { }
            sb.AppendLine("  ],");



            // Components
            sb.AppendLine("  \"Components\": [");
            try
            {
                foreach (ComponentOccurrence occ in assyDoc.ComponentDefinition.Occurrences)
                {
                    Box box = occ.RangeBox;
                    Point min = box.MinPoint;
                    Point max = box.MaxPoint;

                    double sizeX = max.X - min.X;
                    double sizeY = max.Y - min.Y;
                    double sizeZ = max.Z - min.Z;

                    sb.AppendLine("    {");
                    sb.AppendLine($"      \"Name\": \"{EscapeJsonString(occ.Name)}\",");
                    sb.AppendLine($"      \"Type\": \"{EscapeJsonString(occ.DefinitionDocumentType.ToString())}\",");

                    sb.AppendLine("      \"BoundingBox\": {");
                    sb.AppendLine($"        \"MinPoint\": {{ \"X\": {min.X}, \"Y\": {min.Y}, \"Z\": {min.Z} }},");
                    sb.AppendLine($"        \"MaxPoint\": {{ \"X\": {max.X}, \"Y\": {max.Y}, \"Z\": {max.Z} }},");
                    sb.AppendLine($"        \"SizeX\": {sizeX},");
                    sb.AppendLine($"        \"SizeY\": {sizeY},");
                    sb.AppendLine($"        \"SizeZ\": {sizeZ}");
                    sb.AppendLine("      }");

                    sb.AppendLine("    },");
                }
            }
            catch (Exception ex)
            {
                sb.AppendLine($"    {{ \"Error\": \"{EscapeJsonString(ex.Message)}\" }}");
            }
            sb.AppendLine("  ],");



            // Constraints
            sb.AppendLine("  \"Constraints\": [");
            try
            {
                foreach (AssemblyConstraint constraint in assyDoc.ComponentDefinition.Constraints)
                {
                    sb.AppendLine("    {");
                    sb.AppendLine($"      \"Name\": \"{EscapeJsonString(constraint.Name)}\",");
                    sb.AppendLine($"      \"Type\": \"{EscapeJsonString(constraint.Type.ToString())}\",");
                    sb.AppendLine($"      \"Suppressed\": {constraint.Suppressed.ToString().ToLower()}");
                    sb.AppendLine("    },");
                }
            }
            catch { }
            sb.AppendLine("  ],");


            // Joints


            sb.AppendLine("  \"Joints\": [");
            try
            {
                foreach (AssemblyJoint joint in assyDoc.ComponentDefinition.Joints)
                {
                    sb.AppendLine("    {");
                    sb.AppendLine($"      \"Name\": \"{EscapeJsonString(joint.Name)}\",");
                    sb.AppendLine($"      \"Type\": \"{EscapeJsonString(joint.Type.ToString())}\",");
                    sb.AppendLine($"      \"OccurrenceOne\": \"{EscapeJsonString(joint.OccurrenceOne?.Name)}\",");
                    sb.AppendLine($"      \"OccurrenceTwo\": \"{EscapeJsonString(joint.OccurrenceTwo?.Name)}\"");
                    sb.AppendLine("    },");
                }
            }
            catch { }
            sb.AppendLine("  ]");



            sb.AppendLine("}");
            return sb.ToString();
        }


        // Helper for JSON escaping
        private string EscapeJsonString(string input)
        {
            return input?.Replace("\\", "\\\\").Replace("\"", "\\\"") ?? "";
        }



        public void helloWorld()
        {
            string workingDir = System.IO.Directory.GetCurrentDirectory();
            string outputDir = System.IO.Path.Combine(workingDir, "Output");
            string outputPath = System.IO.Path.Combine(outputDir, "output.json");
            string zipPath = System.IO.Path.Combine(workingDir, "Output.zip");

            Exception caughtException = null;


            try
            {
                if (!Directory.Exists(outputDir))
                    Directory.CreateDirectory(outputDir);

              

                string uploadFolderPath = System.IO.Path.Combine(workingDir, "upload");

                if (Directory.Exists(uploadFolderPath))
                {
                    string[] files = Directory.GetFiles(uploadFolderPath, "*", SearchOption.AllDirectories);

                    Console.WriteLine($"[INFO] Found {files.Length} file(s) in 'upload' folder at {DateTime.UtcNow:o}");

                    string assemblyFilePath = null;

                    foreach (string file in files)
                    {
                        string relativePath = file.Replace(uploadFolderPath + "\\", "").Replace("\\", "/");
                        Console.WriteLine($"[INFO] File found: {relativePath} at {DateTime.UtcNow:o}");

                        // Detect .iam assembly file
                        if (file.EndsWith(".iam", StringComparison.OrdinalIgnoreCase))
                        {
                            assemblyFilePath = file;
                        }
                    }

                    if (!string.IsNullOrEmpty(assemblyFilePath))
                    {
                        Console.WriteLine($"[INFO] Assembly file detected: {assemblyFilePath}");

                        try
                        {
                            string jsonOutput = ExtractJointsAndConstraintsInternal(assemblyFilePath);
                            Console.WriteLine($"[SUCCESS] Extracted Joints and Constraints:\n{jsonOutput}");
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine($"[ERROR] Failed to extract joints and constraints: {ex.Message}");
                        }
                    }
                    else
                    {
                        Console.WriteLine("[WARN] No .iam assembly file found in upload folder.");
                    }
                }
                else
                {
                    Console.WriteLine($"[ERROR] Upload folder not found at path '{uploadFolderPath}' at {DateTime.UtcNow:o}");
                }







                if (System.IO.File.Exists(outputPath)) System.IO.File.Delete(outputPath);

                if (System.IO.File.Exists(zipPath)) System.IO.File.Delete(zipPath);



                Console.WriteLine($"[INFO] Cloud execution started at {DateTime.UtcNow:o}\n");
                Console.WriteLine($"[INFO] Working directory: {workingDir}\n");

                System.IO.File.WriteAllText(outputPath, "{ \"status\": \"success\", \"message\": \"Hello World\" }");

                Console.WriteLine($"[INFO] Created output.json at {DateTime.UtcNow:o}\n");



                if (!System.IO.File.Exists(outputPath))
                    throw new Exception("Failed to create output.json - unknown reason");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[CRITICAL ERROR] {ex.Message}\n{ex.StackTrace}");
            }
            finally
            {
                try
                {
                    if (Directory.Exists(outputDir))
                    {
                        ZipFile.CreateFromDirectory(outputDir, zipPath);
                        Console.WriteLine("Output.zip created......................");
                    }
                }
                catch (Exception zipEx)
                {
                    Console.WriteLine($"[ZIP ERROR] {zipEx.Message}\n{zipEx.StackTrace}");
                }
            }

            if (caughtException != null)
            {
                throw caughtException;
            }
                
        }
    }
}

